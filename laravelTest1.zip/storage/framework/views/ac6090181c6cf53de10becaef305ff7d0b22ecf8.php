<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="d-inline-flex">Services</h5>
                        <span class="float-right d-inline-flex">
                            <a href="<?php echo e(route('services.create')); ?>" class="btn btn-outline-info">Add Service</a>
                        </span>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Image</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($service->id); ?></td>
                                    <td><?php echo e($service->title); ?></td>
                                    <td><img style="width: 100px; height: 100px;" src="<?php echo e(asset('storage/'.$service->image)); ?>" alt=""></td>
                                    <td>$<?php echo e($service->price); ?></td>
                                    <td>
                                        <?php if($service->status=='Active'): ?>
                                            <label class="badge badge-success"><?php echo e($service->status); ?></label>
                                        <?php else: ?>
                                            <label class="badge badge-danger"><?php echo e($service->status); ?></label>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($service->status=='Active'): ?>
                                            <a class="btn btn-sm btn-danger" href="<?php echo e(route('services.show',$service->id)); ?>">
                                                InActive
                                            </a>
                                        <?php else: ?>
                                            <a class="btn btn-sm btn-success" href="<?php echo e(route('services.show',$service->id)); ?>">
                                                Active
                                            </a>
                                        <?php endif; ?>
                                        <span class="dropdown">
                                            <button class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-cog"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                                                <a class="dropdown-item" href="<?php echo e(route('services.edit',$service->id)); ?>">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                                <div class="dropdown-divider"></div>
                                                <form action="<?php echo e(route('services.destroy',$service->id)); ?>" method="post" onsubmit="return confirm(' Are you sure want to do this ?');" id="delete-form">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-xs btn-danger dropdown-item">
                                                        <i class="fa fa-trash"></i> Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No records found</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($services->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelTest1\resources\views/admin/services/index.blade.php ENDPATH**/ ?>