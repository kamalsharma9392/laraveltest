<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="d-inline-flex">Bookings</h5>
                        <span class="float-right d-inline-flex">

                        </span>
                    </div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Service</th>
                                <th>User</th>
                                <th>Address</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($booking->id); ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-12">
                                                <img style="width: 50px; height: 50px;" src="<?php echo e(asset('storage/'.$booking->service->image)); ?>" alt="" class="d-inline-flex">
                                                <p><strong><?php echo e($booking->service->title); ?></strong></p>
                                                <p>$<?php echo e($booking->service->price); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="row">
                                            <div class="col-2">
                                                <img style="width: 50px; height: 50px;" src="<?php echo e(asset('storage/'.$booking->user->profile_pic)); ?>" alt="">
                                            </div>
                                            <div class="col-10">
                                                <p><strong><?php echo e($booking->user->name); ?></strong></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($booking->address); ?></td>
                                    <td><?php echo e($booking->start_time); ?></td>
                                    <td><?php echo e($booking->end_time); ?></td>
                                    <td>
                                        <?php if($booking->status=='ACTIVE'): ?>
                                            <label class="badge badge-success"><?php echo e($booking->status); ?></label>
                                        <?php elseif($booking->status=='PENDING'): ?>
                                            <label class="badge badge-warning"><?php echo e($booking->status); ?></label>
                                        <?php else: ?>
                                            <label class="badge badge-secondary"><?php echo e($booking->status); ?></label>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No records found</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($bookings->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelTest1\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>